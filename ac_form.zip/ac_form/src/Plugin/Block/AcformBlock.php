<?php
namespace Drupal\ac_form\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'article' block.
 *
 * @Block(
 *   id = "acform_block",
 *   admin_label = @Translation("AC Block"),
 *   category = @Translation("Custom AC form block")
 * )
 */

class AcformBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
   public function build() {
        $form = \Drupal::formBuilder()->getForm('Drupal\ac_form\Form\ModuleConfigurationForm');
        return  $form;
  }
}