<?php
namespace Drupal\ac_form\Services;

use Drupal\Core\Config\ConfigFactory;

class MyServices {
	 protected $configFactory;
	 
 public function __construct(ConfigFactory $configFactory) {
    $this->configFactory = $configFactory;
  }
 /* public function getCurrentTime() {
    $config = $this->configFactory->get('ac_form.adminsettings');
    return $config->get('ac_form.adminsettings');
  } */
  
   public function getMySetting() {
   /*  $config = $this->configFactory->get('ac_form.adminsettings');
    return $config->get('ac_form.adminsettings'); */
	$date = new DateTime("now", new DateTimeZone('America/New_York') );
    echo $date->format('d-m-Y h:i A');
	
  }
}