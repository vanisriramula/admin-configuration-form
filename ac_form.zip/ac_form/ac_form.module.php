<?php

/**
 * @file
 * Contains ac_form .module.
 */

function get_my_setting() {
   return /Drupal::service('ac_form')->get('ac_form.adminsettings');
}